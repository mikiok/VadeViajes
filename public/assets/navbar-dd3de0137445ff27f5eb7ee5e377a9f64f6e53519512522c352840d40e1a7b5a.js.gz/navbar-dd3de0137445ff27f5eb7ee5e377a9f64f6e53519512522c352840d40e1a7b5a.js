
document.getElementsByClassName("form-control")[0].addEventListener("focus", function(){
	getUsers();
});
